Please see web site for information: http://bots.sourceforge.net
Most documentation is on the wiki: http://code.google.com/p/bots/wiki/StartIntroduction
Bots is licenced under GNU GENERAL PUBLIC LICENSE Version 3; for full text: http://www.gnu.org/copyleft/gpl.html
Commercial support by EbberConsult, http://www.ebbersconsult.com
