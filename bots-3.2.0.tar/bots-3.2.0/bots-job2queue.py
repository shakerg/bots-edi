#!/usr/bin/env python
from bots import job2queue

if __name__ == '__main__':
    job2queue.start()
